/usr/bin/php -q MonitorJBossPerform.php $*
